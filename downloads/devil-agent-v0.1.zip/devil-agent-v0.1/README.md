# Devil Agent — v0.1 (client-side)

The client-side agent and SDK for **Devil Anti-Cheat v0.2**. This is everything
that runs on the player's machine: it collects a hardware hash, verifies game
files against a signed manifest, checks for a virtual machine, and asks your
server whether the hardware is banned — then allows or blocks the launch.

> Versioning: the **agent is v0.1**; the Devil Anti-Cheat system as a whole is
> **v0.2**. They version independently.

## Contents

```
devil-agent-v0.1/
├── client_sdk/                 # the SDK modules
│   ├── devil_client.py         #   DevilClient.verify_launch() — entry point
│   ├── fingerprint.py          #   hardware-hash collection
│   ├── integrity.py            #   Ed25519 signed-manifest verify
│   ├── vmsignal.py             #   VM detection (scored signal)
│   └── blacklist_client.py     #   client for your ban server
├── example_launch.py           # runnable offline example
├── devil_protocol.sample.json  # copy to devil_protocol.json and edit
└── requirements.txt
```

## Requirements

```
pip install -r requirements.txt     # cryptography (for Ed25519)
```

## Run the example

```
python example_launch.py
```

It generates keys, signs a manifest of a dummy game folder, and runs the launch
gate against a fake "not banned" server — so it works with no network.

## Use it for real

1. Generate a keypair once on your build server; keep the private key secret and
   embed the public key in your game.
2. At release, sign a manifest of your shipped files with `integrity`.
3. Copy `devil_protocol.sample.json` to `devil_protocol.json` and set your
   endpoint, auth, field mapping, and fail mode.
4. At launch, call `client.verify_launch(...)` and refuse to start if it returns
   `allow == False`.

The ban decision is a server read, so an approved appeal lifts it with one
write — nothing is written to or hidden on the player's machine.
