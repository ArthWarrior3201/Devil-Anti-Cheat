"""
Example — gate a game launch with the Devil Agent, including signed verdicts.

Runs fully offline: it stands up an in-process "server" that signs its verdict
exactly like your real backend would, so you can see the trusted path end to
end with no network. For real use, you drop a configured devil_protocol.json
next to this file and your actual server does the signing.

    python example_launch.py
"""
import json
import os
import tempfile

from client_sdk import DevilClient, LaunchPolicy, integrity, verdict_auth

# --- 1. Game integrity keys (sign your shipped files) --------------------
game_priv, game_pub = integrity.generate_keypair()
game = tempfile.mkdtemp()
with open(os.path.join(game, "game.exe"), "wb") as f:
    f.write(b"your game binary")
signed_manifest = integrity.sign_manifest(
    integrity.build_manifest(game, ["game.exe"], version="1.0.0"), game_priv)

# --- 2. Server verdict keys (server signs ban/allow; game embeds public) --
srv_priv, srv_pub = integrity.generate_keypair()

# An offline stand-in for your backend. It SIGNS the verdict over the client's
# nonce, which is what a fake local server can't do.
def signing_server(url, payload, headers, method, timeout, verify_tls):
    banned, reason = False, ""                     # this machine isn't banned
    sig = verdict_auth.sign_verdict(payload["nonce"], banned, reason, srv_priv)
    return {"banned": banned, "reason": reason, "sig": sig}

# --- 3. Protocol config requiring signed verdicts -------------------------
cfg_path = os.path.join(tempfile.mkdtemp(), "devil_protocol.json")
with open(cfg_path, "w") as f:
    json.dump({
        "require_signed_response": True,
        "server_public_key": srv_pub,
        "response": {"banned_path": "banned", "reason_path": "reason",
                     "sig_path": "sig"},
    }, f)

# --- 4. Gate the launch ---------------------------------------------------
client = DevilClient(public_key_hex=game_pub, protocol_config_path=cfg_path,
                     blacklist_transport=signing_server)
decision = client.verify_launch(
    game_root=game, signed_manifest=signed_manifest,
    policy=LaunchPolicy(block_vms=False))

print("decision:", decision)
if not decision["allow"]:
    print("->", decision["message"])
    raise SystemExit(1)
print("-> launch allowed (verdict signature verified)")
