"""
Example — gate a game launch with the Devil Agent.

Runs offline (it uses a fake blacklist transport so you can see the flow with
no server). For real use, drop a configured devil_protocol.json next to this
file and remove the `blacklist_transport=` argument.

    python example_launch.py
"""
import os
import tempfile

from client_sdk import DevilClient, LaunchPolicy, integrity

# 1. Keys — generated once on your build server. Keep `priv` secret; embed
#    `pub` in your shipped game.
priv, pub = integrity.generate_keypair()

# 2. At release — sign a manifest of your game's files.
game = tempfile.mkdtemp()
with open(os.path.join(game, "game.exe"), "wb") as f:
    f.write(b"your game binary")
signed = integrity.sign_manifest(
    integrity.build_manifest(game, ["game.exe"], version="1.0.0"), priv)

# 3. At launch — one call gates the game.
#    (Offline example: a fake "not banned" server. For real use, configure
#    devil_protocol.json and drop the transport arg.)
fake_server = lambda *a, **k: {"result": {"banned": False, "reason": ""}}

client = DevilClient(
    public_key_hex=pub,
    protocol_config_path="devil_protocol.sample.json",
    blacklist_transport=fake_server,
)
decision = client.verify_launch(
    game_root=game, signed_manifest=signed,
    policy=LaunchPolicy(block_vms=False))   # block_vms=True refuses VMs

print("decision:", decision)
if not decision["allow"]:
    print("->", decision["message"])        # e.g. "SORRY, YOU ARE BANNED"
    raise SystemExit(1)
print("-> launch allowed")
